# Alaska integration lab

Open `alaska_report.pdf` for the report and `alaska_integration.ipynb` for the code and saved local outputs.

## Run the notebook

1. Use Python 3.12 in a fresh virtual environment.
2. Install dependencies with `python -m pip install -r requirements.txt`.
3. Start JupyterLab in this folder with `python -m jupyter lab`.
4. Open the notebook and choose Run All. The first run downloads the public Alaska monitor archive. Later runs reuse it.

The default run uses actual Alaska records with Pandas, Dask, SQLite/SQLAlchemy, label-based entity evaluation, Matplotlib, and Seaborn. Generated data lives in `lab_data/`; measurements, merged records, and charts live in `lab_results/`. The report describes the saved run, so later timing results may differ.

## Optional services

The notebook clearly marks Spark, MongoDB, and API/Kafka cells as not run in the saved local execution. To execute them:

- Spark: install Java 17 and `pyspark==3.5.7`, then set `RUN_SPARK=True`. Default master is `local[2]`; set `SPARK_MASTER` to use a configured cluster. Local mode is not a distributed performance test.
- MongoDB: start a disposable MongoDB instance; set `MONGO_URI` if needed and enable `RUN_MONGO`. The lab upserts into `alaska_lab.specifications`.
- API/Kafka: provide a running Kafka broker, topic `alaska-events`, `KAFKA_BOOTSTRAP`, and an `API_URL` returning a JSON list with event_id, spec_id, event_time, and price. Before starting Spark, configure `PYSPARK_SUBMIT_ARGS=--packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.7 pyspark-shell`. Enable `RUN_SPARK` and `RUN_STREAM`, restart the kernel, and run all cells. This polls an additional endpoint; Alaska has no live feed in this lab.

The report does not claim that the unexecuted integrations or multi-node performance were measured. Ground truth evaluates cross-source pairs within labeled monitor records only.
